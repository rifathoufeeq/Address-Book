#include "contact.h"

void listContacts(AddressBook *addressBook) 
{
    //printing all the contact details
    printf("Si.No\tName\t\tPhone no.\tEmail id\n");
    printf("----------------------------------------------------------\n");
    for(int i = 0; i < addressBook -> contactCount; i++)
    {
        printf("%d\t%-10s\t%-10s\t%-10s\n",i + 1,addressBook -> contacts[i].name, addressBook -> contacts[i].phone, addressBook -> contacts[i].email);
    }
}



void createContact(AddressBook *addressBook) 
{
    char name_i[50], phone_i[50], email_i[50];

    while(1)
    {
        //read name
        printf("Name : ");
        scanf(" %[^\n]",name_i);

        //validating name
        if(!ValidateName(name_i, addressBook))
        {
            continue;
        }
        break;
    }

    while(1)
    {
        //read number
        getchar();
        printf("Mobile Number : ");
        scanf("%[^\n]",phone_i);

        //validate phone number
        if(!ValidatePhone(phone_i, addressBook))
        {
            continue;
        } 

        break;
    }
    
    while(1)
    {
        //read email
        getchar();
        printf("Email id : ");
        scanf("%[^\n]",email_i);

        //validate email
        if(!ValidateEmail(email_i, addressBook))
        {
            continue;
        } 

        break;
    }
    //after validation storing details to the addressbook     
    strcpy(addressBook -> contacts[addressBook -> contactCount].name,name_i);  
    strcpy(addressBook -> contacts[addressBook -> contactCount].phone,phone_i); 
    strcpy(addressBook -> contacts[addressBook -> contactCount].email,email_i);

    Blue();
    printf("Creating contact is successful\n");
    reset();
    //incrementing contact count
    addressBook -> contactCount++;
    
}
    
    

void searchContact(AddressBook *addressBook) 
{
    //declaring variable option and asking the user on what basis he wants to search
   int option;
   printf("Select Option:\n");
   printf("\t1.Name\n\t2.Mobile Number\n\t3.Email id\n");
   scanf("%d",&option);

   //searching
   switch(option)
   {
        case 1:
        {
            char name_s[50];
            printf("Enter name:");
            scanf(" %[^\n]",name_s);
            
            searchName(addressBook, name_s);
            break;
        }

        case 2:
        {
            char phone_s[10];
            printf("Enter Phone no.:");
            scanf(" %[^\n]",phone_s);

            searchPhone(addressBook, phone_s);
            break;
        
        }

        case 3:
        {
            char email_s[50];
            printf("Enter email id:");
            scanf(" %[^\n]",email_s);

            searchEmail(addressBook, email_s);
            break;
        }
    }
        
   

}

void editContact(AddressBook *addressBook) 
{
    char name_e[50];
    char phone_e[50];
    char email_e[50];

    int index = -1;
    int count = 0;
    int option;

    //asking the user on what basis he/she wants to search
    printf("Select Option:\n");
    printf("\t1.Name\n\t2.Mobile Number\n\t3.Email id\n");
    scanf("%d",&option);

    while (option < 1 || option > 3) 
    {
        printf("Invalid selection. Please select again:\n");
        printf("\t1.Name\n\t2.Mobile Number\n\t3.Email id\n");
        scanf("%d", &option);
    }

    //searching contact
    int ret;
    switch(option)
    {
        case 1:
        {
            printf("Enter name:");
            scanf(" %[^\n]",name_e);
            ret = searchName(addressBook, name_e);
            break;
        }

        case 2:
        {
            printf("Enter Phone no.:");
            scanf(" %[^\n]",phone_e);
            ret = searchPhone(addressBook, phone_e);
            break;
        
        }

        case 3:
        {
            printf("Enter email id:");
            scanf(" %[^\n]",email_e);
            ret = searchEmail(addressBook, email_e);
            break;
        }
    }

    if(ret)
    {
        //getting the serial number to be printed
        int serial;
        printf("Enter the serial no. of contact to be edited : ");
        scanf(" %d",&serial);

        //Getting the required contact to be edited
        for(int i = 0; i < addressBook -> contactCount; i++)
        {
            if(strcasestr(addressBook -> contacts[i].name, name_e) != NULL ||
                strcasestr(addressBook -> contacts[i].phone, phone_e) != NULL ||
                strcasestr(addressBook -> contacts[i].email, email_e) != NULL)
            {
                count++;
                if(serial == count)
                {
                    index = i;
                    break;
                }
            }
            
        }

        //displaying ontact to be edited
        printf("Name : %s \nPhone no: %s \nEmail id: %s\n",
            addressBook -> contacts[index].name ,
            addressBook -> contacts[index].phone ,
            addressBook -> contacts[index].email);

        //asking what the user want to edit
        printf("What you want edit?\n");
        printf("1.Name\n2.Phone no.\n3.Email id\n");
        printf("Select Option:\n");
        scanf(" %d",&option);
            
        //editing
        int edit = 0;
        switch(option)
        {
            case 1:
            {
                //read name
                printf("Name:");
                scanf(" %[^\n]",name_e);

                //validate name
                if(!ValidateName(name_e, addressBook))
                {
                    printf("Invalid Name! Try again.\n");
                    return;
                }

                //store name to that location
                strcpy(addressBook -> contacts[index].name,name_e);
                edit = 1;
                break;

            }
        
            case 2:
            {
                //read phone no
                printf("Mobile No:");
                scanf(" %[^\n]",phone_e);

                //validate phone no
                if(!ValidatePhone(phone_e, addressBook))
                {
                    printf("Invalid Phone! Try again.\n");
                    return;
                }

                //stroing phone number to that location
                strcpy(addressBook -> contacts[index].phone,phone_e); 
                edit = 1;
                break;
            }

            case 3:
            {
                //read email id
                printf("Email id:");
                scanf(" %[^\n]",email_e);

                //validate email id
                if(!ValidateEmail(email_e, addressBook))
                {
                    printf("Invalid Email! Try again.\n");
                    return;
                }

                //storing email id to the selected location
                strcpy(addressBook -> contacts[index].email,email_e);
                edit = 1;
                break;
            }
                
            default:
            {
                printf("Invalid Selection\n");
                edit = 0;
            }

        }
            

        //printing edit is successful
        if(edit)
        {
            Blue();
            printf("Edit is successful\n");
            reset();
        }
    }
    

}

void deleteContact(AddressBook *addressBook) 
{
   
   char name_d[50];
   char select;
   int found = 0;

   while(1)
   {

        //taking the name to delete
        printf("Enter Name to delete : ");
        scanf(" %[^\n]",name_d);
        
        //checking whether the written contact is present or not
        for(int i = 0; i < addressBook -> contactCount ; i++)
        {
            if((strcasecmp(addressBook -> contacts[i].name, name_d)) == 0)
            {
                found = i;
                break;
            }
        }
        
        //priniting statements if contact not found
        if(found == 0)
        {
            printf("Contact Not Found!\n");
            printf("Do you want to continue (Y/N) ?\n");
            scanf(" %c",&select);
            if(select == 'y' || select == 'Y')
            {
                continue;
            }
            else
            {
                return;
            }
        }

        //printing the contact and asking confirmation to delete the contact and deleting
        printf("Name : %s \nPhone no: %s \nEmail id: %s\n",
            addressBook -> contacts[found].name ,
            addressBook -> contacts[found].phone ,
            addressBook -> contacts[found].email);
        red();
        printf("Do you want to delete this contact [Y/N]?\n");
        reset();
        scanf(" %c",&select);
        if(select == 'y' || select == 'Y')
        {
            for(int i = found; i < addressBook -> contactCount - 1; i++)
            {
                strcpy(addressBook -> contacts[i].name, addressBook -> contacts[i + 1].name);
                strcpy(addressBook -> contacts[i].phone, addressBook -> contacts[i + 1].phone);
                strcpy(addressBook -> contacts[i].email, addressBook -> contacts[i + 1].email);

            }

            red();
            printf("Deleted!\n");
            reset();
            break;
        }
        else{
            break;
        }
    }

    //decremented the contactCount
    addressBook -> contactCount-- ;
    
        
   
}

int ValidateName(char name_i[], AddressBook *addressBook)
{
    //validate name:
    
    //check name is already present or not
    for(int i = 0; i < addressBook -> contactCount; i++)
    {
        if(strcasecmp(name_i, addressBook->contacts[i].name) == 0)
        {
            printf("Name is already present\n");
            return 0;
        }
    }

    //check only alphabets are present or space
    int flag = 0;
    for(int i = 0; i < name_i[i] ; i++)
    {
        if(isalpha(name_i[i]) != 0 || name_i[i] == ' ')
        {
            flag++;
        }
    }

    if(flag != strlen(name_i))
    {
        printf("Enter a valid name!\n");
        return 0;
    }

    return 1;
}

int ValidatePhone(char phone_i[], AddressBook *addressBook)
{

    //checking if the number is already present or not
    for(int i = 0; i < addressBook -> contactCount; i++)
    {
        if(strcmp(phone_i,addressBook->contacts[i].phone) == 0)
        {
            printf("Number is already present\n");
            return 0;
        }
    }

    //checking length of mobile number is 10
    if (strlen(phone_i) != 10)
    {
        printf("Phone number must be 10 digits.\n");
        return 0;
    }
    

    //checking all are digits
    for(int i = 0; i < strlen(phone_i); i++)
    {
        if(!isdigit(phone_i[i]))
        {
            printf("Enter a valid phone number!\n");
            return 0;
        }
    }

    return 1;

    
}

int ValidateEmail(char email_i[], AddressBook *addressBook)
{
    //validate mail id
        
    //checking if the character in email id is lowercase, contain @
    int at_count = 0;
    int at_index;
    int dot_index;

    for(int i = 0; email_i[i]; i++)
    {
        if(isupper(email_i[i]))
        {
            printf("Invalid email id!!\n");
            return 0;
        }

        if(email_i[i] == '@')
        {
            at_count++;
        }

    }

    if(at_count != 1)
    {
        printf("Enter a valid email id!\n");
        return 0;
    }

    //checking last characters are .com
    int len = strlen(email_i);
    if(strcmp(&email_i[len - 4],".com") == 0 && len > 5)
    {
        return 1;
    }
    else{
        printf("Invalid email id!\n");
        return 0;
    } 

    //checking @ is present before .com
    for(int i = 0; i < len; i++)
    {
        if(email_i[i] == '@')
        {
            at_index = i;
        }

        if(email_i[i] == '.')
        {
            dot_index = i;
        }
    }

    if(dot_index < at_index + 1 )  
    {
        printf("Enter a valid email id\n");
        return 0;
    }


 
}

int searchName(AddressBook *addressBook, char name_s[])
{
    int found = 0;
    int serial = 1;
    printf("Si.No\tName\t\tPhone no.\tEmail id\n");
    for(int i = 0; i < addressBook -> contactCount; i++)
    {
        if((strcasestr(addressBook -> contacts[i].name, name_s)) != NULL)
        {
            found = 1;
            printf("%d\t%-10s\t%-10s\t%-10s\n",serial,
            addressBook -> contacts[i].name, 
            addressBook -> contacts[i].phone, 
            addressBook -> contacts[i].email);
            serial++;
        }
    }

    if(!found)
    {
        printf("Contact Not Found\n");
        return 0;
    }
    return 1;
}

int searchPhone(AddressBook *addressBook, char phone_s[])
{
    int found = 0;
    int serial = 1;
    printf("Si.No\tName\t\tPhone no.\tEmail id\n");
    for(int i = 0; i < addressBook -> contactCount; i++)
    {
        if((strcasestr(addressBook -> contacts[i].phone, phone_s)) != NULL)
        {
            found = 1;
            printf("%d\t%-10s\t%-10s\t%-10s\n",serial,
                addressBook -> contacts[i].name, 
                addressBook -> contacts[i].phone, 
                addressBook -> contacts[i].email);
                serial++;
        }
    }

    if(!found)
    {
        printf("Contact Not Found\n");
        return 0;
    }

    return 1;
}

int searchEmail(AddressBook *addressBook, char email_s[])

{
    int found = 0;
    int serial = 1;
    printf("Si.No\tName\t\tPhone no.\tEmail id\n");
    for(int i = 0; i < addressBook -> contactCount; i++)
    {
        found = 1;
        if((strcasestr(addressBook -> contacts[i].email, email_s)) != NULL)
        {
            printf("%d\t%-10s\t%-10s\t%-10s\n",serial,
                addressBook -> contacts[i].name, 
                addressBook -> contacts[i].phone, 
                addressBook -> contacts[i].email);
                serial++;
            
        }
    }

    if(!found)
    {
        printf("Contact Not Found\n");
        return 0;
    }

    return 1;
}

void saveContacts(AddressBook *addressBook)
{
    FILE *fp = fopen("contacts.txt","w");

    for(int i = 0; i < addressBook -> contactCount; i++)
    {
        fprintf(fp, "%s,%s,%s\n", addressBook -> contacts[i].name,
            addressBook -> contacts[i].phone,
            addressBook -> contacts[i].email);
    }
    fclose(fp);
}

void red () {
  printf("\033[1;31m");
}

void Blue(){
  printf("\033[0;34m");
}

void reset () {
  printf("\033[0m");
}
