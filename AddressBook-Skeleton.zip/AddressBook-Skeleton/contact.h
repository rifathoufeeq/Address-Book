#ifndef CONTACT_H
#define CONTACT_H

#define MAX_CONTACTS 100
#define _GNU_SOURCE

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include<ctype.h>


typedef struct { 
    char name[50];
    char phone[20];
    char email[50];
} Contact;


typedef struct {
    Contact contacts[100];
    int contactCount;
} AddressBook;

int ValidateName(char *, AddressBook *addressBook);
int ValidatePhone(char *, AddressBook *addressBook);
int ValidateEmail(char *, AddressBook *addressBook);
int searchName(AddressBook *addressBook, char name_s[]);
int searchPhone(AddressBook *addressBook, char phone_s[]);
int searchEmail(AddressBook *addressBook, char email_s[]);
void createContact(AddressBook *addressBook);
void searchContact(AddressBook *addressBook);
void editContact(AddressBook *addressBook);
void deleteContact(AddressBook *addressBook);
void listContacts(AddressBook *addressBook);
void initialize(AddressBook *addressBook);
void saveContacts(AddressBook *addressBook);
void red ();
void Blue();
void reset();


#endif
