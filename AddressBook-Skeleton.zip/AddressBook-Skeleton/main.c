/*
Name: Rifa Thoufeekha
Date:
Description: Addressbook
*/

#include "contact.h"

int main()
{
    AddressBook addressbook;
    AddressBook *addressBook = &addressbook;
    
    //call intitialize
    initialize(addressBook);

    while(1)
    {
        //printing the required options
        int option;
        printf("\n");
        Blue();
        printf("------------------------------WELCOME TO ADDRESSBOOK--------------------------------\n");
        printf("\n");
        reset();
        printf("\t   MENU\n");
        printf("-------------------------------");
        printf("\n");
        printf("\t1.List\n\t2.Create Contact\n\t3.Search\n\t4.Edit Contact\n\t5.Delete Contact\n\t6.Save Contacts\n\t7.Exit\n");

        //read option
        printf("Choose the required option:\n");
        scanf("%d",&option);

        //exit
        if(option == 7)
        {
            exit(0);
        }

        //choosing the required option and doing the function
        switch(option)
        {
            //Listing Contacts
            case 1:
                listContacts(addressBook);
                break;
            
            //Creating Contacts
            case 2:
                createContact(addressBook);
                break;

            //Searching Contacts
            case 3:
                searchContact(addressBook);
                break;

            //Edit Contacts
            case 4:
            editContact(addressBook);
                break;

            //Delete Contact
            case 5:
                deleteContact(addressBook);
                break;

            //Save Contact
            case 6:
                saveContacts(addressBook);
                break;

            //Default
            default:
                printf("Invalid choice. Please try again.\n");

    
        
        }

        char ch; 
        Blue();
        printf("Go back to menu? (Y/N)\n");
        reset();
        scanf(" %c",&ch);

        if(ch == 'Y' || ch == 'y')
        {
            continue;
        }
        else{
            break;
        }
        printf("\n");

            
    }
}
